function OnCardPlay(a_Card)
    
    rivalHero = GetRival()

    AddWeaponDurability(rivalHero, -3)

end