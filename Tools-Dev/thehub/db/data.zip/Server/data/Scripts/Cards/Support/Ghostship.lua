function OnCardPlay(a_Card)

    rivalIndex = GetCurrentRivalID()
    RemoveRandomCardsFromHand(rivalIndex, 2)

end