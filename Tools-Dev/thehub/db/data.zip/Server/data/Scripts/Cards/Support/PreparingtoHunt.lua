function OnCardPlay(a_Card)

    playerID = GetCurrentPlayerID()
    DrawCardFromDeck(playerID, 1)
end