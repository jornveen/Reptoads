function OnCardPlay(a_Card)
    playerIndex = GetCurrentPlayerID()
    AddCardsToHand(playerIndex, "Monkfish", 3)
end