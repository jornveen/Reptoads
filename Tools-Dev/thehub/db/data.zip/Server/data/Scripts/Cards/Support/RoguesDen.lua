function OnCardPlay(a_Card)
    
    playerID = GetCurrentPlayerID()
    RemoveRandomCardFromHand(playerID)
end