function OnCardPlay(a_Card)
       
    
end