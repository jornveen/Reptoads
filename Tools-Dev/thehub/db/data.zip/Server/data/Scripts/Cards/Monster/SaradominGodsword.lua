Function OnCardPlay(card)
    
    playerHero  = GetHero()
    rivalHero   = GetRival()

    print("This card is not supported yet (^_^)")
end