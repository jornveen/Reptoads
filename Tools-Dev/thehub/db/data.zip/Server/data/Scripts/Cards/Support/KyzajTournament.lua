function OnCardPlay(a_Card)
    
    rivalHero = GetRival()

    AddHeroResource(rivalHero, 3)

end