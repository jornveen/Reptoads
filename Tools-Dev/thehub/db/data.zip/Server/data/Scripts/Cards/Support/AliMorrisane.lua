function OnCardPlay(a_Card)
    
    playerHero = GetHero()
    SetHeroWeapon(playerHero, nil)
    
end