function OnCardPlay(a_Card)

    rival = GetRival()
    AddHeroHealth(rival, 2)
end