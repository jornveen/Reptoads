function OnCardPlay(a_Card)

    playerIndex = GetCurrentPlayerID()
    AddRandomCardsToHandBasedOnFamily(playerIndex,"Kalphite", 2)
end