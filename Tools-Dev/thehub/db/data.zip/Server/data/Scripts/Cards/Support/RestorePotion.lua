function OnCardPlay(a_Card)
    
    playerID = GetCurrentPlayerID()
    DrawCardFromDeck(playerID,2)
end