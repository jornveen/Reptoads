function OnCardPlay(a_Card)
    
    playerHero  = GetHero()
    rivalHero   = GetRival()

    DealDamageToHero(playerHero, GetHeroAttack(rivalHero) * -1)
    StealHeroResource(rivalHero, playerHero, 3)

    print("Rival took " .. GetHeroAttack(rivalHero) .. " damage!")
    print("Hero stole 3 gold from the rival!")
end