function OnCardPlay(a_Card)
    
    playerHero  = GetHero()
    rivalHero   = GetRival()

    AddHeroHealth(playerHero, GetHeroAttack(rivalHero) * -1)
    StealHeroResource(rivalHero, playerHero, 3)
end