function OnCardPlay(a_Card)
    
    playerHero = GetHero()

    AddHeroHealth(playerHero, -4)

end