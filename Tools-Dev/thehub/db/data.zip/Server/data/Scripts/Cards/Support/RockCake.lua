function OnCardPlay(a_Card)
    
    playerHero = GetHero()

    AddHeroHealth(playerHero, -3)

end