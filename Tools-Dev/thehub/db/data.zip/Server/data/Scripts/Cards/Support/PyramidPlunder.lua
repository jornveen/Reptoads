function OnCardPlay(a_Card)
    
    rivalHero = GetRival()

    AddHeroResource(rivalHero, 2)

end