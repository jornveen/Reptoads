function OnCardPlay(a_Card)
    
    rivalHero = GetRival()
    AddHeroArmor(rivalHero, 5)

end