function OnCardPlay(a_Card)

    playerID = GetCurrentPlayerID()
    DrawFamilyCardFromDeck(playerID, 1, "Vampyre")
end