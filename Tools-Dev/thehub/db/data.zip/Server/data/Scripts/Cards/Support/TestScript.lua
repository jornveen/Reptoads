function OnCardPlay(a_Card)

    SwitchHeroCards(0)
end