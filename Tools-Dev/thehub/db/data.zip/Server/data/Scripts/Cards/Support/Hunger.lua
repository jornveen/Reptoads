function OnCardPlay(a_Card)
    
    playerHero = GetHero()
    AddHeroHealth(playerHero, -5)

end