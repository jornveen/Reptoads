function OnCardPlay(a_Card)
    
    rivalHero = GetRival()

    AddHeroHealth(rivalHero, -8)
end