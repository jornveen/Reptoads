function OnCardPlay(a_Card)
    
    playerHero = GetHero()

    AddWeaponAttack(playerHero, 3)

end